package multithreading;

public class Demo2 {
	public static void main(String[] args) {
		
	}
}
//Protected : package+ subclasses in diff package

class Task extends Thread{
	
}